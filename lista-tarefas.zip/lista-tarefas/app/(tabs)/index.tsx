import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  FlatList, 
  Keyboard,
  SafeAreaView,
  StatusBar,
  ListRenderItem
} from 'react-native';
import { Ionicons, MaterialIcons, FontAwesome } from '@expo/vector-icons';

// Interface para tipagem das tarefas
interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export default function App() {
  const [task, setTask] = useState<string>('');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskId, setTaskId] = useState<number>(1);

  const addTask = (): void => {
    if (task.trim() === '') {
      alert('Oops! Por favor, digite uma tarefa.');
      return;
    }
    
    setTasks([...tasks, { id: taskId.toString(), text: task, completed: false }]);
    setTaskId(taskId + 1);
    setTask('');
    Keyboard.dismiss();
  };

  const deleteTask = (id: string): void => {
    if (window.confirm('Tem certeza que deseja remover esta tarefa?')) {
      setTasks(tasks.filter(task => task.id !== id));
    }
  };

  const toggleComplete = (id: string): void => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const renderTask: ListRenderItem<Task> = ({ item }) => (
    <View style={[
      styles.taskItem,
      item.completed && styles.taskItemCompleted
    ]}>
      <TouchableOpacity 
        onPress={() => toggleComplete(item.id)}
        style={styles.completeButton}
      >
        <Ionicons 
          name={item.completed ? "checkmark-circle" : "ellipse-outline"} 
          size={24} 
          color={item.completed ? "#8A2BE2" : "#9370DB"} 
        />
      </TouchableOpacity>
      
      <Text style={[
        styles.taskText,
        item.completed && styles.taskTextCompleted
      ]}>
        {item.text}
      </Text>
      
      <TouchableOpacity 
        onPress={() => deleteTask(item.id)}
        style={styles.deleteButton}
        activeOpacity={0.7}
      >
        <MaterialIcons name="delete-outline" size={24} color="#FF6B6B" />
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#6A5ACD" barStyle="light-content" />
      
      {/* Cabeçalho */}
      <View style={styles.header}>
        <Text style={styles.title}>Lista de Tarefas</Text>
      </View>

      {/* Input para adicionar tarefas */}
      <View style={styles.inputContainer}>
        <View style={styles.inputWrapper}>
          <TextInput
            style={styles.input}
            placeholder="O que precisa fazer hoje?"
            placeholderTextColor="#999"
            value={task}
            onChangeText={setTask}
            onSubmitEditing={addTask}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <Ionicons name="add-circle" size={42} color="#9370DB" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Contador de tarefas */}
      <View style={styles.counterContainer}>
        <Text style={styles.counterText}>
          {tasks.filter(t => !t.completed).length} tarefas pendentes
        </Text>
      </View>

      {/* Lista de tarefas */}
      <FlatList
        data={tasks}
        renderItem={renderTask}
        keyExtractor={item => item.id}
        style={styles.taskList}
        contentContainerStyle={tasks.length === 0 ? styles.emptyListContainer : undefined}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <FontAwesome name="list-alt" size={60} color="#D8BFD8" />
            <Text style={styles.emptyText}>Nenhuma tarefa ainda!</Text>
            <Text style={styles.emptySubtext}>
              Adicione tarefas para começar sua lista
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F6FF',
  },
  header: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6A5ACD',
    paddingVertical: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  inputContainer: {
    padding: 20,
    backgroundColor: 'white',
    margin: 16,
    borderRadius: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
    borderRadius: 15,
    fontSize: 16,
    color: '#333',
  },
  addButton: {
    marginLeft: 10,
  },
  counterContainer: {
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  counterText: {
    fontSize: 14,
    color: '#9370DB',
    fontStyle: 'italic',
  },
  taskList: {
    flex: 1,
    paddingHorizontal: 16,
  },
  emptyListContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 15,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  taskItemCompleted: {
    opacity: 0.7,
    backgroundColor: '#F0F0FF',
  },
  completeButton: {
    marginRight: 12,
  },
  taskText: {
    flex: 1,
    fontSize: 16,
    color: '#4B0082',
  },
  taskTextCompleted: {
    textDecorationLine: 'line-through',
    color: '#888',
  },
  deleteButton: {
    padding: 8,
    marginLeft: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#9370DB',
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
    textAlign: 'center',
  },

});